library(tidyverse)
library(tidygraph)

# 1. selection
# 读取组织参与表。
data_dir <- "data/topic1_hf_ecosystem"
membership_records <- read_csv(
  file.path(data_dir, "source_participation.csv"), show_col_types = FALSE
)

# 按项目用途选取 20 个仓库。
selected_repositories <- c(
  "transformers", "datasets", "tokenizers", "diffusers", "accelerate",
  "peft", "trl", "smolagents", "safetensors", "evaluate",
  "transformers.js", "optimum", "text-generation-inference",
  "text-embeddings-inference", "huggingface_hub", "lighteval",
  "datatrove", "lerobot", "open-r1", "candle"
)

selected_records <- membership_records %>%
  filter(repository %in% selected_repositories) %>%
  mutate(is_explicit_bot = grepl("\\[bot\\]$", user, ignore.case = TRUE))

# 排除带 [bot] 后缀的账号，并按账号与仓库去重。
clean_records <- selected_records %>%
  filter(!is_explicit_bot) %>%
  distinct(user_index, repository, .keep_all = TRUE)

# 汇总清理后的记录数与账号数。
clean_records %>%
  summarise(records = n(), accounts = n_distinct(user_index))

# 2. build_graph
# 读取节点、边和参与对照表。
data_dir <- "data/topic1_hf_ecosystem"
developers <- read_csv(file.path(data_dir, "developers.csv"), show_col_types = FALSE)
edges <- read_csv(file.path(data_dir, "edges.csv"), show_col_types = FALSE)
contributions <- read_csv(file.path(data_dir, "contributions.csv"), show_col_types = FALSE)

# 按参与仓库数区分单仓库与跨仓库账号。
developers <- developers %>%
  mutate(participation = if_else(repository_count >= 2L, "cross", "single"))

# 通过 developer_id 匹配边的两端，构建无向图。
github_graph <- tbl_graph(
  nodes = developers, edges = edges,
  directed = FALSE, node_key = "developer_id"
)

# 3. participation
# 从图对象提取节点，统计账号数与占比。
participation_counts <- github_graph %>%
  activate(nodes) %>%
  as_tibble() %>%
  count(participation, name = "accounts") %>%
  mutate(share = accounts / sum(accounts))

participation_counts

# 4. projection
# 提取不重复的仓库与账号组合。
repository_pairs <- contributions %>%
  distinct(repository_id, developer_id)

# 在同一仓库内配对账号，汇总每对账号的共同仓库数。
projected_edges <- inner_join(
  repository_pairs, repository_pairs, by = "repository_id",
  relationship = "many-to-many"
) %>%
  filter(developer_id.x < developer_id.y) %>%
  count(from = developer_id.x, to = developer_id.y,
        name = "shared_repositories")

