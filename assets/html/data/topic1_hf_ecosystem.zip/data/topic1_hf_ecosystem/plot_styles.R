# 语义颜色与图形映射。透明画布使内嵌图自然融入章节背景。
topic1_font_family <- "sans"
if (.Platform$OS.type == "windows") {
  grDevices::windowsFonts(`Microsoft YaHei` = grDevices::windowsFont("Microsoft YaHei"))
  topic1_font_family <- "Microsoft YaHei"
}
topic1_metric_labels <- c(degree = "度中心性", betweenness = "标准化中介中心性", pagerank = "PageRank")
# 节点颜色只表示类别；所有节点共享填充 alpha = 0.60，避免增加指标含义。
# 轮廓与填充分开设置。深色使用浅亮细轮廓，不加扩大遮挡范围的模糊光晕。
topic1_themes <- list(
  light = list(background = "#F8F9FB", text = "#26323B", muted = "#4E5F70", edge = "#6C7F8C",
               edge_alpha = 0.045, edge_width = 0.11, fill_alpha = 0.60,
               stroke_alpha = 0.90, node_stroke = 0.20,
               fill = c(single = "#5795B6", cross = "#C58B3E"),
               stroke = c(single = "#2F708F", cross = "#936722"),
               community_fill = c("#679DAF", "#C6975D", "#73A897", "#A69BBF", "#C58777",
                                  "#A1AB68", "#75AEB8", "#BC8FA8", "#929EA5"),
               community_stroke = c("#346B80", "#926326", "#397961", "#756493", "#A65845",
                                    "#747E35", "#3B7C86", "#8E607D", "#5D707A")),
  dark = list(background = "#171A21", text = "#E5E9F1", muted = "#B8C5D4", edge = "#92A9BA",
              edge_alpha = 0.035, edge_width = 0.11, fill_alpha = 0.60,
              stroke_alpha = 0.90, node_stroke = 0.20,
              fill = c(single = "#76B5D2", cross = "#D6AF6A"),
              stroke = c(single = "#A2CBDF", cross = "#E7C78D"),
              community_fill = c("#80B6CB", "#D5B17B", "#86BFA9", "#B2A5D2", "#D7A08F",
                                 "#BAC38A", "#8BC6CE", "#C9A8BD", "#B3BCC2"),
              community_stroke = c("#B6DAE7", "#EDD5AE", "#B3DCCD", "#D6CBEA", "#EAC6BB",
                                   "#DAE2B3", "#BAE4E7", "#E2CEDB", "#D8E0E4"))
)
topic1_plot_theme <- function(mode = "light", preview_background = FALSE) {
  palette <- topic1_themes[[mode]]
  fill <- if (preview_background) palette$background else "transparent"
  theme_graph(base_family = topic1_font_family, base_size = 11) +
    theme(text = element_text(family = topic1_font_family, colour = palette$text),
          plot.background = element_rect(fill = fill, colour = NA),
          panel.background = element_rect(fill = fill, colour = NA),
          plot.margin = margin(4, 6, 3, 6, unit = "mm"),
          legend.position = "bottom", legend.direction = "horizontal", legend.box = "vertical",
          legend.box.just = "center", legend.background = element_rect(fill = fill, colour = NA),
          legend.key = element_rect(fill = fill, colour = NA),
          legend.title = element_text(size = 10.3, colour = palette$text, face = "bold"),
          legend.text = element_text(size = 9.8, colour = palette$muted),
          legend.key.width = grid::unit(6, "mm"), legend.key.height = grid::unit(6, "mm"),
          legend.spacing.y = grid::unit(0.6, "mm"), legend.margin = margin(0, 0, 0, 0))
}
