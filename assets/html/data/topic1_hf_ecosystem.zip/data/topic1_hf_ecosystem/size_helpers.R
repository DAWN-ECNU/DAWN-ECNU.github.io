# Fisher–Jenks 节点大小映射。输入必须为同一完整网络的指标向量。
# 该函数只决定图形大小，不更改中心性、节点、边、社区或坐标。
topic1_fisher_mapping <- function(values, metric) {
  stopifnot(metric %in% c("degree", "betweenness", "pagerank"),
            is.numeric(values), length(values) > 0L,
            all(is.finite(values)), all(values >= 0))
  if (!requireNamespace("classInt", quietly = TRUE)) {
    stop("需要 classInt 包；请先在 Console 运行 install.packages('classInt')。")
  }
  # 中介为零有明确含义，单列一档；其余指标在全量值上分为六档。
  zero_separate <- identical(metric, "betweenness") && any(values == 0)
  active <- if (zero_separate) values > 0 else rep(TRUE, length(values))
  target_classes <- if (zero_separate) 5L else 6L
  positive_values <- values[active]
  class_count <- min(target_classes, length(unique(positive_values)))
  if (class_count < 1L) {
    fisher_breaks <- numeric()
    active_class <- integer()
  } else if (class_count == 1L) {
    fisher_breaks <- range(positive_values)
    active_class <- rep(1L, length(positive_values))
  } else {
    # 全部 408 个账号参与分级，不抽样；相同值不会被切到不同档。
    intervals <- classInt::classIntervals(
      positive_values, n = class_count, style = "fisher",
      intervalClosure = "right", largeN = Inf, warnLargeN = FALSE
    )
    fisher_breaks <- unique(as.numeric(intervals$brks))
    class_count <- length(fisher_breaks) - 1L
    active_class <- as.integer(cut(
      positive_values, breaks = fisher_breaks,
      include.lowest = TRUE, right = TRUE, labels = FALSE
    ))
  }
  offset <- as.integer(zero_separate)
  ids <- integer(length(values))
  if (zero_separate) ids[!active] <- 1L
  ids[active] <- active_class + offset
  total_classes <- class_count + offset
  stopifnot(total_classes > 0L, !anyNA(ids), all(ids >= 1L))
  # 名义圆点直径单位为 mm。小档更小，大档更大，以增强大小层级。
  diameter_values <- c(0.65, 1.1, 1.9, 3.2, 5.4, 8.6)
  if (total_classes != length(diameter_values)) {
    diameter_values <- exp(seq(log(0.65), log(8.6), length.out = total_classes))
  }
  bins <- lapply(seq_len(total_classes), function(id) {
    observed <- values[ids == id]
    if (zero_separate && id == 1L) {
      lower <- upper <- 0
      lower_inclusive <- TRUE
    } else {
      active_id <- id - offset
      lower <- fisher_breaks[active_id]
      upper <- fisher_breaks[active_id + 1L]
      lower_inclusive <- active_id == 1L
    }
    data.frame(id = id, lower = lower, upper = upper,
               lower_inclusive = lower_inclusive, upper_inclusive = TRUE,
               observed_min = min(observed), observed_max = max(observed),
               count = length(observed), size_mm = diameter_values[id])
  })
  bins <- do.call(rbind, bins)
  # 图例列出各档实际观测范围；中介与 PageRank 默认保留三位有效数字。
  # 仅在相邻档位显示为同一标签时增加精度；计算边界始终保留完整精度。
  digits <- if (metric == "degree") 16L else 3L
  format_values <- function(x) {
    if (metric == "degree") return(format(x, scientific = FALSE, trim = TRUE))
    vapply(x, function(value) {
      if (value == 0) "0" else trimws(formatC(value, digits = digits, format = "g"))
    }, character(1))
  }
  repeat {
    lower_labels <- format_values(bins$observed_min)
    upper_labels <- format_values(bins$observed_max)
    adjacent_same <- length(lower_labels) > 1L &&
      any(head(upper_labels, -1L) == tail(lower_labels, -1L))
    if (!adjacent_same || digits >= 15L || metric == "degree") break
    digits <- digits + 1L
  }
  range_labels <- ifelse(bins$observed_min == bins$observed_max,
                         lower_labels, paste0(lower_labels, "–", upper_labels))
  bins$label <- range_labels
  stopifnot(sum(bins$count) == length(values), !anyDuplicated(bins$label),
            all(bins$size_mm > 0), all(diff(bins$size_mm) > 0))
  list(class = factor(ids, levels = seq_len(total_classes), ordered = TRUE),
       class_id = ids,
       size_mm = bins$size_mm[ids],
       sizes = setNames(bins$size_mm, as.character(bins$id)),
       labels = setNames(bins$label, as.character(bins$id)),
       bins = bins, breaks = fisher_breaks,
       zero_separate = zero_separate, number_of_classes = total_classes,
       method = "classInt::classIntervals(style = 'fisher'); all input values; right-closed")
}
