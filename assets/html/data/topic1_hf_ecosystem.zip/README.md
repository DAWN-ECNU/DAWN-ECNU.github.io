2.2 代码：section22_workflow.R
完整专题脚本：topic1_analysis.R

# Hugging Face AI 开源工具生态：开发者共同参与网络

将 topic1_analysis.R 与 data 文件夹一起解压到一个 R 项目目录，再依次运行脚本。
一次性安装依赖可在 Console 执行：install.packages(c("readr", "dplyr", "tidyr", "tidygraph", "ggraph", "ggplot2", "classInt"))。

本包为二十仓库的人工目的性教学样本：408账号、594条开发者—仓库记录、7856条无向边。
source_participation.csv 为 GONets 的 Hugging Face 原始组织图整理出的3296条参与记录。
repositories.csv 记录完整名单、原有/新增、项目用途、纳入理由与官方链接。
其余表包括节点、边、参与对照、固定FR坐标及本次指标结果。

来源：Dutta, Khan, Shah and Nanavati，GONets v1，2026。
https://zenodo.org/records/18472549
数据许可：CC BY 4.0。采集范围为2025-06-01至2025-12-31；采集范围不等于贡献事件发生时间。

边表示两个账号共同出现在至少一个所选仓库的贡献记录中，不保证直接交流或同期协作。
仅删除用户名带[bot]后缀的显式自动化账号，不保证剩余账号全部为真人。
来源中每个已查仓库最多30条贡献账号记录，不能将此包当作GitHub或Hugging Face的完整生态。

节点与边按来源索引的稳定顺序导出。Louvain：seed=20261111，无权，9社区，Q约0.554676652。
FR坐标：seed=20261112，weights=NA，niter=2000；所有课堂图复用同一坐标。
包版本和源码见课程第六章专题研究1的配套构建目录。

节点大小使用 Fisher–Jenks 六档：degree与PageRank六档；中介为零单列，正值五档。size_helpers.R为便携函数；size_breaks.json保留完整断点与边界规则，size_classes.csv保留逐账号档号。分级只改变显示，同档内差异仍需查看原值与排名。

浅深主题：plot_styles.R 与页面静态图采用同一套配置，类别为蓝／琥珀色，填充 alpha=0.60、轮廓 alpha=0.90。调整 plot_mode 后重新运行绘图段；不会改变指标或布局。
parent_scope/ 提供较大组织范围对照图的独立数据与 stress 坐标，不参与课堂408账号的中心性与社区计算。
