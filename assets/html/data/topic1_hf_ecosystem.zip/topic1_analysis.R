# Hugging Face AI 开源工具生态：开发者共同参与网络

# 将本脚本与 data 文件夹放在同一 R 项目，依次运行；主题可选 light / dark。

# c6_topic1_selection_code

# 1. 加载数据整理工具，并读取原始组织参与表。
library(dplyr)
library(readr)

data_dir <- "data/topic1_hf_ecosystem"
membership_records <- read_csv(
  file.path(data_dir, "source_participation.csv"), show_col_types = FALSE
)
# 2. 固定研究仓库名单；不按中心性或聚类结果反向选样。
selected_repositories <- c(
  "transformers", "datasets", "tokenizers", "diffusers", "accelerate",
  "peft", "trl", "smolagents", "safetensors", "evaluate",
  "transformers.js", "optimum", "text-generation-inference",
  "text-embeddings-inference", "huggingface_hub", "lighteval",
  "datatrove", "lerobot", "open-r1", "candle"
)

# 3. 提取所选仓库，并用完整 [bot] 后缀标记显式机器人。
selected_records <- membership_records %>%
  filter(repository %in% selected_repositories) %>%
  mutate(is_explicit_bot = grepl("\\[bot\\]$", user, ignore.case = TRUE))

# 4. 排除显式机器人，再保证每个账号—仓库组合只保留一行。
clean_records <- selected_records %>%
  filter(!is_explicit_bot) %>%
  distinct(user_index, repository, .keep_all = TRUE)

# 5. 核对处理后的参与记录与不同账号数量。
stopifnot(nrow(clean_records) == 594L,
          n_distinct(clean_records$user_index) == 408L)

# c6_topic1_read_tables

# 1. 准备依赖与数据位置；这段可独立于前面的选学代码运行。
library(dplyr)
library(readr)
library(tidygraph)
data_dir <- "data/topic1_hf_ecosystem"

# 2. 分别读取节点表、边表和参与对照表。
developers <- read_csv(file.path(data_dir, "developers.csv"), show_col_types = FALSE)
edges <- read_csv(file.path(data_dir, "edges.csv"), show_col_types = FALSE)
contributions <- read_csv(file.path(data_dir, "contributions.csv"), show_col_types = FALSE)

# 3. 统一字符型主键，并从参与仓库数生成参与类型。
developers <- developers %>%
  mutate(
    developer_id = as.character(developer_id),
    participation = if_else(repository_count >= 2L, "cross", "single")
  )
edges <- edges %>%
  mutate(from = as.character(from), to = as.character(to))

# 4. 检查节点主键、边端点、自环与重复边。
stopifnot(!anyNA(developers$developer_id),
          !anyDuplicated(developers$developer_id),
          all(edges$from %in% developers$developer_id),
          all(edges$to %in% developers$developer_id),
          all(edges$from != edges$to),
          !anyDuplicated(edges[c("from", "to")]))

# 5. 以 developer_id 连接两张表，构建无向图。
github_graph <- tbl_graph(
  nodes = developers, edges = edges,
  directed = FALSE, node_key = "developer_id"
)

# c6_topic1_participation_counts

# 提取节点属性，统计单／跨仓库账号数及其占比。
participation_counts <- github_graph %>%
  activate(nodes) %>%
  as_tibble() %>%
  count(participation, name = "accounts") %>%
  mutate(share = accounts / sum(accounts))
participation_counts

# c6_topic1_projection_code

# 1. 只保留仓库与账号键，参与表已按二者去重。
repository_pairs <- contributions %>%
  select(repository_id, developer_id)

# 2. 在同仓库内两两配对，只保留一种顺序的不同账号对。
projected_edges <- inner_join(
  repository_pairs, repository_pairs, by = "repository_id",
  relationship = "many-to-many"
) %>%
  filter(developer_id.x < developer_id.y) %>%
  # 3. 合并重复账号对：出现于几个仓库，边属性就记为几。
  count(from = developer_id.x, to = developer_id.y,
        name = "shared_repositories")

# 4. 与课堂边表核对边的条数。
stopifnot(nrow(projected_edges) == nrow(edges))

# c6_topic1_fixed_layout

# 1. 加载绘图工具，读取已保存的算法坐标。
library(ggraph)
library(ggplot2)

coordinates <- read_csv(file.path(data_dir, "shared_layout.csv"), show_col_types = FALSE)
# 2. 按当前节点顺序连接坐标；不能直接按行号拼接。
plot_coordinates <- github_graph %>%
  activate(nodes) %>%
  as_tibble() %>%
  select(developer_id) %>%
  left_join(coordinates, by = "developer_id")

stopifnot(!anyNA(plot_coordinates[c("x", "y")]))
# 3. manual 表示复用坐标，不是人工安排节点位置。
github_layout <- create_layout(
  github_graph, layout = "manual",
  x = plot_coordinates$x, y = plot_coordinates$y
)

# c6_topic1_basic_plot_code

# 1. 载入随数据包提供的浅深主题；改为 "dark" 可输出深色版本。
source(file.path(data_dir, "plot_styles.R"), encoding = "UTF-8")
plot_mode <- "light"
palette <- topic1_themes[[plot_mode]]

# 2. 先绘低透明度的边，再绘同样大小的节点。
#    填充 alpha 为 0.60，轮廓 alpha 为 0.90；二者分别设置。
p_basic <- ggraph(github_layout) +
  geom_edge_link0(colour = palette$edge, alpha = palette$edge_alpha,
                  linewidth = palette$edge_width) +
  geom_node_point(
    shape = 21, size = 1.45, stroke = palette$node_stroke,
    fill = scales::alpha(palette$fill[["single"]], palette$fill_alpha),
    colour = scales::alpha(palette$stroke[["single"]], palette$stroke_alpha)
  ) +
  topic1_plot_theme(plot_mode) +
  theme(legend.position = "none")
p_basic

# c6_topic1_parent_plot_code

# 1. 读取较大范围的数据；不重新选样，也不重新计算坐标。
parent_dir <- file.path(data_dir, "parent_scope")
parent_nodes <- read_csv(file.path(parent_dir, "nodes.csv"), show_col_types = FALSE)
parent_edges <- read_csv(file.path(parent_dir, "edges.csv"), show_col_types = FALSE)
parent_coordinates <- parent_nodes %>% select(name) %>%
  left_join(read_csv(file.path(parent_dir, "layout.csv"), show_col_types = FALSE), by = "name")
stopifnot(nrow(parent_nodes) == 2020L, nrow(parent_edges) == 31839L,
          !anyNA(parent_coordinates[c("x", "y")]))
parent_graph <- tbl_graph(nodes = parent_nodes, edges = parent_edges,
                          directed = FALSE, node_key = "name")
parent_layout <- create_layout(parent_graph, layout = "manual",
                                x = parent_coordinates$x, y = parent_coordinates$y)

# 2. 沿用相同主题，较密集网络采用更细、更淡的连线。
palette <- topic1_themes[[plot_mode]]
p_parent <- ggraph(parent_layout) +
  geom_edge_link0(colour = palette$edge,
                  alpha = if (plot_mode == "dark") 0.025 else 0.03, linewidth = 0.09) +
  geom_node_point(
    shape = 21, size = 0.95, stroke = 0.16,
    fill = scales::alpha(palette$fill[["single"]], palette$fill_alpha),
    colour = scales::alpha(palette$stroke[["single"]], palette$stroke_alpha)
  ) +
  topic1_plot_theme(plot_mode) + theme(legend.position = "none")
p_parent

# c6_topic1_centrality_calculation

# 1. 在完整网络的节点表上计算三个无权中心性。
github_graph <- github_graph %>%
  activate(nodes) %>%
  mutate(
    degree = centrality_degree(weights = NA),
    betweenness = centrality_betweenness(weights = NA, normalized = TRUE),
    pagerank = centrality_pagerank(weights = NA, directed = FALSE)
  )

# 2. 提取指标表，供分级与排名对照使用。
github_metrics <- github_graph %>% activate(nodes) %>% as_tibble()
# 3. 给带指标的新图对象挂回同一组固定坐标。
github_layout <- create_layout(
  github_graph, layout = "manual",
  x = plot_coordinates$x, y = plot_coordinates$y
)

# c6_topic1_plot_helper

# 1. 载入 Fisher–Jenks 分级函数和同一套浅深色主题。
source(file.path(data_dir, "size_helpers.R"), encoding = "UTF-8")
source(file.path(data_dir, "plot_styles.R"), encoding = "UTF-8")

plot_centrality <- function(layout, metric, size_label, mode = "light") {
  palette <- topic1_themes[[mode]]
  # 2. 在完整网络上分级；按指标从小到大绘点，不在筛选后重新求断点。
  mapping <- topic1_fisher_mapping(layout[[metric]], metric)
  layout$size_class <- mapping$class
  layout$colour_category <- factor(layout$participation, levels = c("single", "cross"))
  point_data <- layout[order(layout[[metric]], layout$developer_id), ]
  participation_labels <- paste0(
    c("单仓库参与 = ", "跨仓库参与 = "), as.integer(table(layout$colour_category))
  )

  # 3. 类别用蓝色与琥珀色区分；仅让填充半透明，保留清楚的细轮廓。
  ggraph(layout) +
    geom_edge_link0(colour = palette$edge, alpha = palette$edge_alpha,
                    linewidth = palette$edge_width) +
    geom_node_point(
      data = point_data,
      aes(size = size_class, fill = colour_category, colour = colour_category),
      shape = 21, stroke = palette$node_stroke
    ) +
    scale_fill_manual(
      name = "参与类型", values = scales::alpha(palette$fill, palette$fill_alpha),
      limits = c("single", "cross"), breaks = c("single", "cross"),
      labels = participation_labels, drop = FALSE
    ) +
    scale_colour_manual(
      values = scales::alpha(palette$stroke, palette$stroke_alpha),
      limits = c("single", "cross"), guide = "none"
    ) +
    # 4. 六档名义直径与网页一致；图例显示每档实际观测范围。
    scale_size_manual(
      name = paste0(size_label, "（Fisher 分级）"),
      values = mapping$sizes, breaks = names(mapping$sizes),
      labels = mapping$labels, drop = FALSE
    ) +
    topic1_plot_theme(mode) +
    guides(
      fill = guide_legend(order = 1, nrow = 1,
                          override.aes = list(size = 2.9, alpha = 1,
                                              colour = unname(palette$stroke))),
      size = guide_legend(order = 2, nrow = 2, byrow = TRUE,
                          override.aes = list(fill = palette$muted,
                                              colour = palette$muted, alpha = 0.8))
    )
}

# c6_topic1_degree_code

# 调用公共绘图函数：用 度 的 Fisher 档位映射大小。
p_degree <- plot_centrality(github_layout, "degree", "度中心性", mode = plot_mode)
p_degree

# c6_topic1_betweenness_code

# 调用公共绘图函数：用 中介 的 Fisher 档位映射大小。
p_betweenness <- plot_centrality(github_layout, "betweenness", "标准化中介中心性", mode = plot_mode)
p_betweenness

# c6_topic1_pagerank_code

# 调用公共绘图函数：用 PageRank 的 Fisher 档位映射大小。
p_pagerank <- plot_centrality(github_layout, "pagerank", "PageRank", mode = plot_mode)
p_pagerank

# c6_topic1_account_ranking

# 1. 每个指标单独排名；并列数值获得相同名次。
account_ranking <- github_metrics %>%
  mutate(
    degree_rank = min_rank(desc(degree)),
    betweenness_rank = min_rank(desc(betweenness)),
    pagerank_rank = min_rank(desc(pagerank))
  )
# 2. 按中介排名读取账号，比较其他指标下的位置。
account_ranking %>%
  arrange(betweenness_rank) %>%
  select(github_name, repository_count, degree_rank, betweenness_rank, pagerank_rank) %>%
  slice_head(n = 8)

# c6_topic1_louvain_calculation

# 1. 固定社区算法的随机状态；它与布局种子相互独立。
set.seed(20261111)
# 2. 在相同的完整无权图上生成每个账号的社区编号。
github_graph <- github_graph %>%
  activate(nodes) %>%
  mutate(community = group_louvain(weights = NA))

# 3. 汇总社区人数，并计算本次划分的模块度。
community_nodes <- github_graph %>% activate(nodes) %>% as_tibble()
community_sizes <- community_nodes %>% count(community, name = "accounts")
modularity_value <- with_graph(
  github_graph, graph_modularity(community, weights = NA)
)

# c6_topic1_louvain_plot_code

# 1. 读取相同主题，将包含社区归属的图对象挂回同一组坐标。
palette <- topic1_themes[[plot_mode]]
github_layout <- create_layout(
  github_graph, layout = "manual",
  x = plot_coordinates$x, y = plot_coordinates$y
)
layout_data <- github_layout
layout_data$metric_value <- layout_data$pagerank

# 2. 沿用 PageRank 的六档大小，并准备九个社区的颜色与人数标签。
mapping <- topic1_fisher_mapping(layout_data$pagerank, "pagerank")
layout_data$size_class <- mapping$class
community_levels <- as.character(sort(unique(layout_data$community)))
layout_data$colour_category <- factor(layout_data$community, levels = community_levels)
community_counts <- table(layout_data$colour_category)
community_labels <- paste0(
  community_levels, " (", as.integer(community_counts), ")"
)
community_fills <- setNames(palette$community_fill[seq_along(community_levels)], community_levels)
community_strokes <- setNames(palette$community_stroke[seq_along(community_levels)], community_levels)
point_data <- layout_data[order(layout_data$metric_value, layout_data$developer_id), ]

# 3. 小节点先绘、大节点后绘；颜色表示社区，大小表示 PageRank 档位。
p_louvain <- ggraph(layout_data) +
  geom_edge_link0(colour = palette$edge, alpha = palette$edge_alpha,
                  linewidth = palette$edge_width) +
  geom_node_point(
    data = point_data,
    aes(size = size_class, fill = colour_category, colour = colour_category),
    shape = 21, stroke = palette$node_stroke
  ) +
  scale_fill_manual(
    name = "社区（账号数）", values = scales::alpha(community_fills, palette$fill_alpha),
    limits = community_levels, breaks = community_levels,
    labels = community_labels, drop = FALSE
  ) +
  scale_colour_manual(values = scales::alpha(community_strokes, palette$stroke_alpha), limits = community_levels, guide = "none") +
  scale_size_manual(
    name = "PageRank（Fisher 分级）",
    values = mapping$sizes, breaks = names(mapping$sizes),
    labels = mapping$labels, drop = FALSE
  ) +
  topic1_plot_theme(plot_mode) +
  guides(
    fill = guide_legend(order = 1, nrow = 2,
                        override.aes = list(size = 2.9, alpha = 1,
                                            colour = unname(community_strokes))),
    size = guide_legend(order = 2, nrow = 2, byrow = TRUE,
                        override.aes = list(fill = palette$muted, colour = palette$muted, alpha = 0.8))
  )
p_louvain

# c6_topic1_community_repository

# 1. 把社区归属连接回原始参与表，按社区与仓库统计人数。
community_repository <- contributions %>%
  left_join(community_nodes %>% select(developer_id, community), by = "developer_id") %>%
  count(community, repository_name, name = "participants") %>%
  # 2. 补全没有参与者的组合，再计算该仓库占社区人数的比例。
  tidyr::complete(community, repository_name, fill = list(participants = 0L)) %>%
  left_join(community_sizes, by = "community") %>%
  mutate(share = participants / accounts)

# 3. 先摘要每组参与人数最多的两个仓库，完整矩阵另行保留。
community_repository %>%
  group_by(community) %>%
  slice_max(participants, n = 2, with_ties = FALSE) %>%
  ungroup()

# c6_topic1_account_lookup

# 1. 为每个账号整理其实际参与仓库，保留可追溯记录。
account_repositories <- contributions %>%
  group_by(developer_id) %>%
  summarise(repositories = paste(sub("^huggingface/", "", repository_name),
                                 collapse = ", "), .groups = "drop")

# 2. 找出两端社区不同的边；每条无向边在边表中只出现一次。
edge_communities <- edges %>%
  left_join(community_nodes %>% select(from = developer_id, from_community = community),
            by = "from") %>%
  left_join(community_nodes %>% select(to = developer_id, to_community = community),
            by = "to") %>%
  filter(from_community != to_community)

# 3. 分别累计边两端账号连接到的其他社区邻居数。
cross_community_accounts <- bind_rows(
  edge_communities %>% transmute(developer_id = from),
  edge_communities %>% transmute(developer_id = to)
) %>%
  count(developer_id, name = "cross_community_neighbors")

# 4. 合并社区、三种排名、跨社区邻居数与仓库组合，供逐账号回查。
key_accounts <- community_nodes %>%
  left_join(account_ranking %>% select(developer_id, degree_rank,
                                      betweenness_rank, pagerank_rank), by = "developer_id") %>%
  left_join(cross_community_accounts, by = "developer_id") %>%
  left_join(account_repositories, by = "developer_id") %>%
  mutate(cross_community_neighbors = tidyr::replace_na(cross_community_neighbors, 0L)) %>%
  arrange(betweenness_rank) %>%
  select(developer_id, github_name, community, repository_count,
         degree_rank, betweenness_rank, pagerank_rank,
         cross_community_neighbors, repositories)

# c6_topic1_strength_extension

# 汇总相连边的共同仓库数；这里计算节点强度，不是提交次数。
github_strength <- github_graph %>%
  activate(nodes) %>%
  mutate(strength = centrality_degree(weights = shared_repositories))
